
scoreboard players add @s td_bounces 1
execute at @s run playsound minecraft:block.anvil.place player @a ~ ~ ~ 0.35 1.85
execute at @s run particle minecraft:sweep_attack ~ ~ ~ 0 0 0 0 1 normal
execute at @s run particle minecraft:crit ~ ~ ~ 0.2 0.2 0.2 0.1 6 normal
# Up to 4 ricochet bounces before returning to player
execute if score @s td_bounces matches 5.. run function throwing_disc:start_return
