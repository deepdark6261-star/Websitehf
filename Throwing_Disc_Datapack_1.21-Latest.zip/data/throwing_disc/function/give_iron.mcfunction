loot give @s loot throwing_disc:items/iron_throwing_disc
