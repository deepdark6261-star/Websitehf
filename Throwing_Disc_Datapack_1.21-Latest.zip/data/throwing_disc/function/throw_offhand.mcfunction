
# Read tier stats from weapon.offhand
scoreboard players set #dmg td_dmg 10
scoreboard players set #max_dur td_tmp 190
execute if items entity @s weapon.offhand minecraft:carrot_on_a_stick[minecraft:custom_data~{td_iron:1b}] run scoreboard players set #dmg td_dmg 12
execute if items entity @s weapon.offhand minecraft:carrot_on_a_stick[minecraft:custom_data~{td_iron:1b}] run scoreboard players set #max_dur td_tmp 250
execute if items entity @s weapon.offhand minecraft:carrot_on_a_stick[minecraft:custom_data~{td_gold:1b}] run scoreboard players set #dmg td_dmg 11
execute if items entity @s weapon.offhand minecraft:carrot_on_a_stick[minecraft:custom_data~{td_gold:1b}] run scoreboard players set #max_dur td_tmp 120
execute if items entity @s weapon.offhand minecraft:carrot_on_a_stick[minecraft:custom_data~{td_diamond:1b}] run scoreboard players set #dmg td_dmg 15
execute if items entity @s weapon.offhand minecraft:carrot_on_a_stick[minecraft:custom_data~{td_diamond:1b}] run scoreboard players set #max_dur td_tmp 480
execute if items entity @s weapon.offhand minecraft:carrot_on_a_stick[minecraft:custom_data~{td_netherite:1b}] run scoreboard players set #dmg td_dmg 18
execute if items entity @s weapon.offhand minecraft:carrot_on_a_stick[minecraft:custom_data~{td_netherite:1b}] run scoreboard players set #max_dur td_tmp 620

# Sharpness bonus
execute if items entity @s weapon.offhand minecraft:carrot_on_a_stick[minecraft:enchantments~[{enchantments:"minecraft:sharpness",levels:1}]] run scoreboard players add #dmg td_dmg 2
execute if items entity @s weapon.offhand minecraft:carrot_on_a_stick[minecraft:enchantments~[{enchantments:"minecraft:sharpness",levels:2}]] run scoreboard players add #dmg td_dmg 3
execute if items entity @s weapon.offhand minecraft:carrot_on_a_stick[minecraft:enchantments~[{enchantments:"minecraft:sharpness",levels:3}]] run scoreboard players add #dmg td_dmg 4
execute if items entity @s weapon.offhand minecraft:carrot_on_a_stick[minecraft:enchantments~[{enchantments:"minecraft:sharpness",levels:4}]] run scoreboard players add #dmg td_dmg 5
execute if items entity @s weapon.offhand minecraft:carrot_on_a_stick[minecraft:enchantments~[{enchantments:"minecraft:sharpness",levels:{min:5}}]] run scoreboard players add #dmg td_dmg 6

# Lightweight enchantment -> outbound sub-steps (0.225 blocks/step, 4 sub-steps/tick)
# Base: 56 (~12.6 blocks), Lv1: 88 (~19.8 blocks), Lv2: 124 (~27.9 blocks), Lv3: 164 (~36.9 blocks)
scoreboard players set #max td_max 56
execute if items entity @s weapon.offhand minecraft:carrot_on_a_stick[minecraft:enchantments~[{enchantments:"throwing_disc:lightweight",levels:1}]] run scoreboard players set #max td_max 88
execute if items entity @s weapon.offhand minecraft:carrot_on_a_stick[minecraft:enchantments~[{enchantments:"throwing_disc:lightweight",levels:2}]] run scoreboard players set #max td_max 124
execute if items entity @s weapon.offhand minecraft:carrot_on_a_stick[minecraft:enchantments~[{enchantments:"throwing_disc:lightweight",levels:{min:3}}]] run scoreboard players set #max td_max 164

# Piercing enchantment (Crossbow): Base 2, Lv1=3, Lv2=4, Lv3+=5
scoreboard players set #hit_max td_hit_max 2
execute if items entity @s weapon.offhand minecraft:carrot_on_a_stick[minecraft:enchantments~[{enchantments:"minecraft:piercing",levels:1}]] run scoreboard players set #hit_max td_hit_max 3
execute if items entity @s weapon.offhand minecraft:carrot_on_a_stick[minecraft:enchantments~[{enchantments:"minecraft:piercing",levels:2}]] run scoreboard players set #hit_max td_hit_max 4
execute if items entity @s weapon.offhand minecraft:carrot_on_a_stick[minecraft:enchantments~[{enchantments:"minecraft:piercing",levels:{min:3}}]] run scoreboard players set #hit_max td_hit_max 5

# Harvesting enchantment
scoreboard players set #harv td_harv 0
execute if items entity @s weapon.offhand minecraft:carrot_on_a_stick[minecraft:enchantments~[{enchantments:"throwing_disc:harvesting",levels:{min:1}}]] run scoreboard players set #harv td_harv 1

# Fire Aspect enchantment
scoreboard players set #fire td_fire 0
execute if items entity @s weapon.offhand minecraft:carrot_on_a_stick[minecraft:enchantments~[{enchantments:"minecraft:fire_aspect",levels:1}]] run scoreboard players set #fire td_fire 1
execute if items entity @s weapon.offhand minecraft:carrot_on_a_stick[minecraft:enchantments~[{enchantments:"minecraft:fire_aspect",levels:{min:2}}]] run scoreboard players set #fire td_fire 2

# Unbreaking (0..3)
scoreboard players set #unb td_tmp 0
execute if items entity @s weapon.offhand minecraft:carrot_on_a_stick[minecraft:enchantments~[{enchantments:"minecraft:unbreaking",levels:1}]] run scoreboard players set #unb td_tmp 1
execute if items entity @s weapon.offhand minecraft:carrot_on_a_stick[minecraft:enchantments~[{enchantments:"minecraft:unbreaking",levels:2}]] run scoreboard players set #unb td_tmp 2
execute if items entity @s weapon.offhand minecraft:carrot_on_a_stick[minecraft:enchantments~[{enchantments:"minecraft:unbreaking",levels:{min:3}}]] run scoreboard players set #unb td_tmp 3

# Roll durability usage (1 per throw in Survival/Adventure, respecting Unbreaking)
scoreboard players set #take_dur td_tmp 0
execute if entity @s[gamemode=!creative] if score #unb td_tmp matches 0 run scoreboard players set #take_dur td_tmp 1
execute if entity @s[gamemode=!creative] if score #unb td_tmp matches 1 store result score #roll td_tmp run random value 0..1
execute if entity @s[gamemode=!creative] if score #unb td_tmp matches 1 if score #roll td_tmp matches 0 run scoreboard players set #take_dur td_tmp 1
execute if entity @s[gamemode=!creative] if score #unb td_tmp matches 2 store result score #roll td_tmp run random value 0..2
execute if entity @s[gamemode=!creative] if score #unb td_tmp matches 2 if score #roll td_tmp matches 0 run scoreboard players set #take_dur td_tmp 1
execute if entity @s[gamemode=!creative] if score #unb td_tmp matches 3 store result score #roll td_tmp run random value 0..3
execute if entity @s[gamemode=!creative] if score #unb td_tmp matches 3 if score #roll td_tmp matches 0 run scoreboard players set #take_dur td_tmp 1

# Set hand flag (1 = mainhand, 2 = offhand)
scoreboard players set #hand td_tmp 2

# Spawn disc & copy EXACT item from weapon.offhand
scoreboard players operation #owner td_id = @s td_id
tag @s add td_thrower
execute anchored eyes positioned ^ ^ ^0.6 run function throwing_disc:spawn_disc
tag @s remove td_thrower

# Remove disc from weapon.offhand so 1 throw at a time until it returns!
item replace entity @s weapon.offhand with minecraft:air
playsound minecraft:item.trident.throw player @a ~ ~ ~ 0.9 1.35
