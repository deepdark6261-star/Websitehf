
execute if items entity @s weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_data~{throwing_disc:1b}] run return run function throwing_disc:throw_mainhand
execute if items entity @s weapon.offhand minecraft:carrot_on_a_stick[minecraft:custom_data~{throwing_disc:1b}] run return run function throwing_disc:throw_offhand
