
scoreboard objectives add td_use minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add td_id dummy
scoreboard objectives add td_uid dummy
scoreboard objectives add td_steps dummy
scoreboard objectives add td_max dummy
scoreboard objectives add td_dmg dummy
scoreboard objectives add td_harv dummy
scoreboard objectives add td_fire dummy
scoreboard objectives add td_hits dummy
scoreboard objectives add td_hit_max dummy
scoreboard objectives add td_bounces dummy
scoreboard objectives add td_life dummy
scoreboard objectives add td_x dummy
scoreboard objectives add td_y dummy
scoreboard objectives add td_z dummy
scoreboard objectives add td_vx dummy
scoreboard objectives add td_vy dummy
scoreboard objectives add td_vz dummy
scoreboard objectives add td_tmp dummy
scoreboard objectives add throwing_disc trigger

scoreboard players add #next_id td_id 0
scoreboard players add #next_uid td_uid 0
scoreboard players set #neg1 td_tmp -1

tellraw @a [{"text":"[Throwing Disc] ","color":"aqua","bold":true},{"text":"v4 loaded! ","color":"green","bold":false},{"text":"Main + Offhand, True Angle Ricochet & Fixed Return-to-Hand ready.","color":"gray"}]
