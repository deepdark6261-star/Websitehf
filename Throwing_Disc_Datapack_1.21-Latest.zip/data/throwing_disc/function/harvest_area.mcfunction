
execute if block ~ ~ ~ #throwing_disc:harvestable run setblock ~ ~ ~ minecraft:air destroy
execute if block ~1 ~ ~ #throwing_disc:harvestable run setblock ~1 ~ ~ minecraft:air destroy
execute if block ~-1 ~ ~ #throwing_disc:harvestable run setblock ~-1 ~ ~ minecraft:air destroy
execute if block ~ ~ ~1 #throwing_disc:harvestable run setblock ~ ~ ~1 minecraft:air destroy
execute if block ~ ~ ~-1 #throwing_disc:harvestable run setblock ~ ~ ~-1 minecraft:air destroy
execute if block ~ ~-1 ~ #throwing_disc:harvestable run setblock ~ ~-1 ~ minecraft:air destroy
execute if block ~1 ~-1 ~ #throwing_disc:harvestable run setblock ~1 ~-1 ~ minecraft:air destroy
execute if block ~-1 ~-1 ~ #throwing_disc:harvestable run setblock ~-1 ~-1 ~ minecraft:air destroy
execute if block ~ ~-1 ~1 #throwing_disc:harvestable run setblock ~ ~-1 ~1 minecraft:air destroy
execute if block ~ ~-1 ~-1 #throwing_disc:harvestable run setblock ~ ~-1 ~-1 minecraft:air destroy
