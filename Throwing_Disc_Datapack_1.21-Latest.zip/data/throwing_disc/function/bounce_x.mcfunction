
scoreboard players operation @s td_x = #old_x td_x
execute store result entity @s Pos[0] double 0.001 run scoreboard players get @s td_x
scoreboard players operation @s td_vx *= #neg1 td_tmp
scoreboard players set #bounced td_tmp 1
