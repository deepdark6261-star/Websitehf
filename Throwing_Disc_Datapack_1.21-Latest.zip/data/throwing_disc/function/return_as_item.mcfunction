
# Guard: never summon placeholder if the linked visual item_display is already gone
execute unless entity @e[type=minecraft:item_display,tag=td_vis_cur] run return 0
summon minecraft:item ~ ~0.2 ~ {PickupDelay:20s,Tags:["td_ret_drop"],Item:{id:"minecraft:carrot_on_a_stick",count:1}}
data modify entity @e[type=minecraft:item,tag=td_ret_drop,limit=1] Item set from entity @e[type=minecraft:item_display,tag=td_vis_cur,limit=1] item
data merge entity @e[type=minecraft:item,tag=td_ret_drop,limit=1] {PickupDelay:0s}
tag @e[type=minecraft:item,tag=td_ret_drop] remove td_ret_drop
