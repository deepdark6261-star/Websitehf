
execute if score #cur_hits td_hits >= #cur_hit_max td_hit_max run return 0
tag @s add td_hit_ret
scoreboard players add #cur_hits td_hits 1
function throwing_disc:apply_damage
