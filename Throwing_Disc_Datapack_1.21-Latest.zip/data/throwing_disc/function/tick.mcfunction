
scoreboard players enable @a throwing_disc
execute as @a[scores={throwing_disc=1..}] run function throwing_disc:menu

execute as @a unless score @s td_id matches 1.. run function throwing_disc:assign_id

execute as @a[scores={td_use=1..}] at @s run function throwing_disc:try_throw
scoreboard players set @a[scores={td_use=1..}] td_use 0

execute as @e[type=minecraft:marker,tag=td_disc] at @s run function throwing_disc:disc_tick
