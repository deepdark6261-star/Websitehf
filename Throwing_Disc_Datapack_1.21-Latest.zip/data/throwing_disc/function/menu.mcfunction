
scoreboard players set @s throwing_disc 0
tellraw @s [{"text":"=== ","color":"dark_gray"},{"text":"Throwing Disc Datapack v4","color":"aqua","bold":true},{"text":" ===","color":"dark_gray"}]
tellraw @s [{"text":"Hands: ","color":"yellow"},{"text":"Works in BOTH Mainhand & Offhand (returns to same hand).","color":"white"}]
tellraw @s [{"text":"Durability: ","color":"yellow"},{"text":"Gold 120 | Copper 190 | Iron 250 | Diamond 480 | Netherite 620","color":"white"}]
tellraw @s [{"text":"Mob Hit Limit: ","color":"yellow"},{"text":"Base 2 | Piercing I = 3 | Piercing II = 4 | Piercing III = 5","color":"white"}]
tellraw @s [{"text":"OP Test Command: ","color":"green"},{"text":"/function throwing_disc:give_all","color":"aqua"}]
