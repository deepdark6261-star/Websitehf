loot give @s loot throwing_disc:items/netherite_throwing_disc
