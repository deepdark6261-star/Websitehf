
tag @s remove td_out
tag @s add td_ret
execute at @s run tag @e[distance=..64,tag=td_hit_out] remove td_hit_out
