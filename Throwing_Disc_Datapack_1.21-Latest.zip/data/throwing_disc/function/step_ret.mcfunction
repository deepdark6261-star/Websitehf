
execute at @s facing entity @a[tag=td_owner,limit=1] eyes run tp @s ^ ^ ^0.65 ~ ~

execute at @s if score #cur_harv td_harv matches 1.. run function throwing_disc:harvest_area

scoreboard players operation #cur_hits td_hits = @s td_hits
execute if score #cur_hits td_hits < #cur_hit_max td_hit_max at @s as @e[type=!#throwing_disc:non_damageable,distance=..1.25,tag=!td_owner,tag=!td_hit_ret,sort=nearest] run function throwing_disc:hit_ret
scoreboard players operation @s td_hits = #cur_hits td_hits

execute at @a[tag=td_owner,limit=1] anchored eyes positioned ^ ^ ^ if entity @s[distance=..1.8] run return run function throwing_disc:disc_catch
execute at @s if entity @a[tag=td_owner,distance=..2.25] run return run function throwing_disc:disc_catch
