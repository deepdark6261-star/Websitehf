loot give @s loot throwing_disc:items/copper_throwing_disc
