
scoreboard players operation @s td_z = #old_z td_z
execute store result entity @s Pos[2] double 0.001 run scoreboard players get @s td_z
scoreboard players operation @s td_vz *= #neg1 td_tmp
scoreboard players set #bounced td_tmp 1
