# Apply thrown damage credited to owner
execute if score #cur_dmg td_dmg matches 10 run damage @s 5 minecraft:thrown by @a[tag=td_owner,limit=1]
execute if score #cur_dmg td_dmg matches 11 run damage @s 5.5 minecraft:thrown by @a[tag=td_owner,limit=1]
execute if score #cur_dmg td_dmg matches 12 run damage @s 6 minecraft:thrown by @a[tag=td_owner,limit=1]
execute if score #cur_dmg td_dmg matches 13 run damage @s 6.5 minecraft:thrown by @a[tag=td_owner,limit=1]
execute if score #cur_dmg td_dmg matches 14 run damage @s 7 minecraft:thrown by @a[tag=td_owner,limit=1]
execute if score #cur_dmg td_dmg matches 15 run damage @s 7.5 minecraft:thrown by @a[tag=td_owner,limit=1]
execute if score #cur_dmg td_dmg matches 16 run damage @s 8 minecraft:thrown by @a[tag=td_owner,limit=1]
execute if score #cur_dmg td_dmg matches 17 run damage @s 8.5 minecraft:thrown by @a[tag=td_owner,limit=1]
execute if score #cur_dmg td_dmg matches 18 run damage @s 9 minecraft:thrown by @a[tag=td_owner,limit=1]
execute if score #cur_dmg td_dmg matches 19 run damage @s 9.5 minecraft:thrown by @a[tag=td_owner,limit=1]
execute if score #cur_dmg td_dmg matches 20 run damage @s 10 minecraft:thrown by @a[tag=td_owner,limit=1]
execute if score #cur_dmg td_dmg matches 21 run damage @s 10.5 minecraft:thrown by @a[tag=td_owner,limit=1]
execute if score #cur_dmg td_dmg matches 22 run damage @s 11 minecraft:thrown by @a[tag=td_owner,limit=1]
execute if score #cur_dmg td_dmg matches 23 run damage @s 11.5 minecraft:thrown by @a[tag=td_owner,limit=1]
execute if score #cur_dmg td_dmg matches 24 run damage @s 12 minecraft:thrown by @a[tag=td_owner,limit=1]
execute if score #cur_dmg td_dmg matches 25.. run damage @s 12.5 minecraft:thrown by @a[tag=td_owner,limit=1]
execute if score #cur_fire td_fire matches 1 run data merge entity @s {Fire:80s}
execute if score #cur_fire td_fire matches 2.. run data merge entity @s {Fire:160s}
execute at @s run playsound minecraft:entity.player.attack.crit player @a ~ ~ ~ 0.7 1.25
execute at @s run particle minecraft:damage_indicator ~ ~1 ~ 0.25 0.25 0.25 0.05 4 normal
