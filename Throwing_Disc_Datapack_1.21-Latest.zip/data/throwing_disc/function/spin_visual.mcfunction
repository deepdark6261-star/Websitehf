
tp @s ~ ~ ~
execute at @s run tp @s ~ ~ ~ ~45 0
