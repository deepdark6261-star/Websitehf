
# Precise axis-by-axis 3D reflection (incident angle = reflected angle on any X/Y/Z block face!)
scoreboard players set #bounced td_tmp 0

# Test X axis
scoreboard players operation #old_x td_x = @s td_x
scoreboard players operation @s td_x += @s td_vx
execute store result entity @s Pos[0] double 0.001 run scoreboard players get @s td_x
execute at @s unless block ~ ~ ~ #throwing_disc:passable run function throwing_disc:bounce_x

# Test Y axis
scoreboard players operation #old_y td_y = @s td_y
scoreboard players operation @s td_y += @s td_vy
execute store result entity @s Pos[1] double 0.001 run scoreboard players get @s td_y
execute at @s unless block ~ ~ ~ #throwing_disc:passable run function throwing_disc:bounce_y

# Test Z axis
scoreboard players operation #old_z td_z = @s td_z
scoreboard players operation @s td_z += @s td_vz
execute store result entity @s Pos[2] double 0.001 run scoreboard players get @s td_z
execute at @s unless block ~ ~ ~ #throwing_disc:passable run function throwing_disc:bounce_z

execute if score #bounced td_tmp matches 1 run function throwing_disc:on_bounce
execute if entity @s[tag=td_ret] run return 0

scoreboard players add @s td_steps 1

# Harvesting enchantment
execute at @s if score #cur_harv td_harv matches 1.. run function throwing_disc:harvest_area

# Piercing mob hit with strict limit (Base 2, Piercing I=3, II=4, III=5)
scoreboard players operation #cur_hits td_hits = @s td_hits
execute at @s as @e[type=!#throwing_disc:non_damageable,distance=..1.25,tag=!td_owner,tag=!td_hit_out,sort=nearest] run function throwing_disc:hit_out
scoreboard players operation @s td_hits = #cur_hits td_hits

execute if score @s td_hits >= @s td_hit_max run return run function throwing_disc:start_return
execute if score @s td_steps >= @s td_max run return run function throwing_disc:start_return
