
# Summon physics marker & aim marker 0.225 blocks ahead along exact 3D look vector
summon minecraft:marker ~ ~ ~ {Tags:["td_disc","td_out","td_new"]}
summon minecraft:marker ^ ^ ^0.225 {Tags:["td_aim"]}

execute store result score #p0x td_x run data get entity @e[type=minecraft:marker,tag=td_new,limit=1] Pos[0] 1000
execute store result score #p0y td_y run data get entity @e[type=minecraft:marker,tag=td_new,limit=1] Pos[1] 1000
execute store result score #p0z td_z run data get entity @e[type=minecraft:marker,tag=td_new,limit=1] Pos[2] 1000

execute store result score #p1x td_x run data get entity @e[type=minecraft:marker,tag=td_aim,limit=1] Pos[0] 1000
execute store result score #p1y td_y run data get entity @e[type=minecraft:marker,tag=td_aim,limit=1] Pos[1] 1000
execute store result score #p1z td_z run data get entity @e[type=minecraft:marker,tag=td_aim,limit=1] Pos[2] 1000
kill @e[type=minecraft:marker,tag=td_aim]

scoreboard players operation #p1x td_x -= #p0x td_x
scoreboard players operation #p1y td_y -= #p0y td_y
scoreboard players operation #p1z td_z -= #p0z td_z

scoreboard players add #next_uid td_uid 1

execute if score #hand td_tmp matches 1 run tag @e[type=minecraft:marker,tag=td_new,limit=1] add td_from_main
execute if score #hand td_tmp matches 2 run tag @e[type=minecraft:marker,tag=td_new,limit=1] add td_from_off

execute as @e[type=minecraft:marker,tag=td_new,limit=1] run scoreboard players operation @s td_id = #owner td_id
execute as @e[type=minecraft:marker,tag=td_new,limit=1] run scoreboard players operation @s td_uid = #next_uid td_uid
execute as @e[type=minecraft:marker,tag=td_new,limit=1] run scoreboard players operation @s td_dmg = #dmg td_dmg
execute as @e[type=minecraft:marker,tag=td_new,limit=1] run scoreboard players operation @s td_max = #max td_max
execute as @e[type=minecraft:marker,tag=td_new,limit=1] run scoreboard players operation @s td_harv = #harv td_harv
execute as @e[type=minecraft:marker,tag=td_new,limit=1] run scoreboard players operation @s td_fire = #fire td_fire
execute as @e[type=minecraft:marker,tag=td_new,limit=1] run scoreboard players operation @s td_hit_max = #hit_max td_hit_max
execute as @e[type=minecraft:marker,tag=td_new,limit=1] run scoreboard players set @s td_hits 0
execute as @e[type=minecraft:marker,tag=td_new,limit=1] run scoreboard players set @s td_bounces 0
execute as @e[type=minecraft:marker,tag=td_new,limit=1] run scoreboard players set @s td_steps 0
execute as @e[type=minecraft:marker,tag=td_new,limit=1] run scoreboard players set @s td_life 0
execute as @e[type=minecraft:marker,tag=td_new,limit=1] run scoreboard players operation @s td_x = #p0x td_x
execute as @e[type=minecraft:marker,tag=td_new,limit=1] run scoreboard players operation @s td_y = #p0y td_y
execute as @e[type=minecraft:marker,tag=td_new,limit=1] run scoreboard players operation @s td_z = #p0z td_z
execute as @e[type=minecraft:marker,tag=td_new,limit=1] run scoreboard players operation @s td_vx = #p1x td_x
execute as @e[type=minecraft:marker,tag=td_new,limit=1] run scoreboard players operation @s td_vy = #p1y td_y
execute as @e[type=minecraft:marker,tag=td_new,limit=1] run scoreboard players operation @s td_vz = #p1z td_z

# Summon item_display & copy the EXACT held item from the thrower's active hand (mainhand or offhand)
summon minecraft:item_display ~ ~ ~ {Tags:["td_visual","td_vis_new"],teleport_duration:1,transformation:{left_rotation:[0.7071068f,0.0f,0.0f,0.7071068f],right_rotation:[0.0f,0.0f,0.0f,1.0f],translation:[0.0f,0.0f,0.0f],scale:[1.15f,1.15f,1.15f]}}
execute if score #hand td_tmp matches 1 run item replace entity @e[type=minecraft:item_display,tag=td_vis_new,limit=1] contents from entity @a[tag=td_thrower,limit=1] weapon.mainhand
execute if score #hand td_tmp matches 2 run item replace entity @e[type=minecraft:item_display,tag=td_vis_new,limit=1] contents from entity @a[tag=td_thrower,limit=1] weapon.offhand
execute as @e[type=minecraft:item_display,tag=td_vis_new,limit=1] run scoreboard players operation @s td_uid = #next_uid td_uid

# Apply +1 durability damage onto the stored item (if #take_dur == 1)
scoreboard players set #cur_dur td_tmp 0
execute store result score #cur_dur td_tmp run data get entity @e[type=minecraft:item_display,tag=td_vis_new,limit=1] item.components."minecraft:damage" 1
execute if score #take_dur td_tmp matches 1 run scoreboard players add #cur_dur td_tmp 1
execute if score #take_dur td_tmp matches 1 if score #cur_dur td_tmp >= #max_dur td_tmp run tag @e[type=minecraft:marker,tag=td_new,limit=1] add td_will_break
execute if score #take_dur td_tmp matches 1 if score #cur_dur td_tmp < #max_dur td_tmp store result entity @e[type=minecraft:item_display,tag=td_vis_new,limit=1] item.components."minecraft:damage" int 1 run scoreboard players get #cur_dur td_tmp

tag @e[type=minecraft:marker,tag=td_new] remove td_new
tag @e[type=minecraft:item_display,tag=td_vis_new] remove td_vis_new
