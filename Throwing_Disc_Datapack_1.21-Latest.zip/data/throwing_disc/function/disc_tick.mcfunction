
scoreboard players set #neg1 td_tmp -1
scoreboard players add @s td_life 1

scoreboard players operation #cur_owner td_id = @s td_id
scoreboard players operation #cur_uid td_uid = @s td_uid
scoreboard players operation #cur_dmg td_dmg = @s td_dmg
scoreboard players operation #cur_harv td_harv = @s td_harv
scoreboard players operation #cur_fire td_fire = @s td_fire
scoreboard players operation #cur_hits td_hits = @s td_hits
scoreboard players operation #cur_hit_max td_hit_max = @s td_hit_max

tag @a remove td_owner
execute as @a if score @s td_id = #cur_owner td_id run tag @s add td_owner

# Safety return after 300 ticks (15s) or if owner far away
execute if score @s td_life matches 300.. run return run function throwing_disc:disc_catch
execute unless entity @a[tag=td_owner,distance=..160] run return run function throwing_disc:disc_catch

# Run 4 crisp sub-steps per tick outbound (0.225 blocks/substep = 0.9 blocks/tick) for accurate angle reflection!
execute if entity @s[tag=td_out] at @s run function throwing_disc:step_out
execute if entity @s[tag=td_out] at @s run function throwing_disc:step_out
execute if entity @s[tag=td_out] at @s run function throwing_disc:step_out
execute if entity @s[tag=td_out] at @s run function throwing_disc:step_out

# Return flight (2 sub-steps of 0.65 blocks = 1.3 blocks/tick)
execute if entity @s[tag=td_disc,tag=td_ret] at @s run function throwing_disc:step_ret
execute if entity @s[tag=td_disc,tag=td_ret] at @s run function throwing_disc:step_ret

execute unless entity @s[tag=td_disc] run return 0

# Sync & spin the linked item_display
execute at @s as @e[type=minecraft:item_display,tag=td_visual] if score @s td_uid = #cur_uid td_uid run function throwing_disc:spin_visual

# Flight particles
execute at @s if score #cur_fire td_fire matches 1.. run particle minecraft:flame ~ ~ ~ 0.08 0.05 0.08 0.01 2 normal
execute at @s if score #cur_fire td_fire matches 0 run particle minecraft:crit ~ ~ ~ 0.08 0.04 0.08 0.01 1 normal
execute at @s if score #cur_harv td_harv matches 1.. run particle minecraft:happy_villager ~ ~ ~ 0.15 0.05 0.15 0.01 1 normal

tag @a remove td_owner
