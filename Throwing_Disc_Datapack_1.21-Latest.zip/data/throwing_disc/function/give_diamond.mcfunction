loot give @s loot throwing_disc:items/diamond_throwing_disc
