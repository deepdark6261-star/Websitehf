
scoreboard players add #next_id td_id 1
scoreboard players operation @s td_id = #next_id td_id
