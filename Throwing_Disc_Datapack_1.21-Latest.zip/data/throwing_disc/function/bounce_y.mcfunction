
scoreboard players operation @s td_y = #old_y td_y
execute store result entity @s Pos[1] double 0.001 run scoreboard players get @s td_y
scoreboard players operation @s td_vy *= #neg1 td_tmp
scoreboard players set #bounced td_tmp 1
