
execute unless entity @s[tag=td_disc] run return 0
scoreboard players operation #del_uid td_uid = @s td_uid
tag @e[type=minecraft:item_display,tag=td_vis_cur] remove td_vis_cur
execute as @e[type=minecraft:item_display,tag=td_visual] if score @s td_uid = #del_uid td_uid run tag @s add td_vis_cur

execute if entity @s[tag=td_will_break] at @a[tag=td_owner,limit=1] run playsound minecraft:entity.item.break player @a ~ ~ ~ 1.0 1.0
execute if entity @s[tag=td_will_break] run return run function throwing_disc:disc_cleanup

scoreboard players set #returned td_tmp 0

# Return straight to offhand if thrown from offhand and offhand is empty
execute if entity @s[tag=td_from_off] if entity @a[tag=td_owner,limit=1] unless items entity @a[tag=td_owner,limit=1] weapon.offhand * run function throwing_disc:return_to_offhand

# Return straight to mainhand if thrown from mainhand and mainhand is empty
execute if score #returned td_tmp matches 0 if entity @s[tag=td_from_main] if entity @a[tag=td_owner,limit=1] unless items entity @a[tag=td_owner,limit=1] weapon.mainhand * run function throwing_disc:return_to_mainhand

# Fallback: if that hand is occupied, safely drop exact Throwing Disc at player (NEVER a plain carrot_on_a_stick!)
execute if score #returned td_tmp matches 0 if entity @a[tag=td_owner,limit=1] at @a[tag=td_owner,limit=1] run function throwing_disc:return_as_item

execute at @a[tag=td_owner,limit=1] run playsound minecraft:entity.item.pickup player @a ~ ~ ~ 0.8 1.4
function throwing_disc:disc_cleanup
