
item replace entity @a[tag=td_owner,limit=1] weapon.mainhand from entity @e[type=minecraft:item_display,tag=td_vis_cur,limit=1] contents
scoreboard players set #returned td_tmp 1
