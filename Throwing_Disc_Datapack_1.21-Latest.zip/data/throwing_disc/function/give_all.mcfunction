
loot give @s loot throwing_disc:items/copper_throwing_disc
loot give @s loot throwing_disc:items/iron_throwing_disc
loot give @s loot throwing_disc:items/gold_throwing_disc
loot give @s loot throwing_disc:items/diamond_throwing_disc
loot give @s loot throwing_disc:items/netherite_throwing_disc
loot give @s loot throwing_disc:books/piercing_3
loot give @s loot throwing_disc:books/lightweight_3
loot give @s loot throwing_disc:books/harvesting_1
loot give @s loot throwing_disc:books/unbreaking_3
loot give @s loot throwing_disc:books/mending_1
tellraw @s [{"text":"[Throwing Disc] ","color":"aqua","bold":true},{"text":"Given all 5 Throwing Discs + Piercing III, Lightweight III, Harvesting I, Unbreaking III & Mending books!","color":"green","bold":false}]
