
scoreboard players operation #del_uid td_uid = @s td_uid
execute at @s run tag @e[distance=..96,tag=td_hit_out] remove td_hit_out
execute at @s run tag @e[distance=..96,tag=td_hit_ret] remove td_hit_ret
execute as @e[type=minecraft:item_display,tag=td_visual] if score @s td_uid = #del_uid td_uid run kill @s
tag @s remove td_disc
tag @s remove td_out
tag @s remove td_ret
tag @s remove td_from_main
tag @s remove td_from_off
kill @s
