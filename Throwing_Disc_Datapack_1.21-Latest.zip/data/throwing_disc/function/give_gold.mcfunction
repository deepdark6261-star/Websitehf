loot give @s loot throwing_disc:items/gold_throwing_disc
