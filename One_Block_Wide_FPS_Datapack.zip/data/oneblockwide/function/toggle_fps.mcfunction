scoreboard players add #global obw_ultra_fps 1
execute if score #global obw_ultra_fps matches 2.. run scoreboard players set #global obw_ultra_fps 0

execute if score #global obw_ultra_fps matches 1 run tellraw @s ["",{"text":"[1-Line Worldgen] ","color":"aqua","bold":true},{"text":"Ultra FPS Void Cleanup: ","color":"gray"},{"text":"ON","color":"green","bold":true}]
execute if score #global obw_ultra_fps matches 0 run tellraw @s ["",{"text":"[1-Line Worldgen] ","color":"aqua","bold":true},{"text":"Ultra FPS Void Cleanup: ","color":"gray"},{"text":"OFF","color":"yellow","bold":true}]

scoreboard players set @s obw_fps_boost 0
