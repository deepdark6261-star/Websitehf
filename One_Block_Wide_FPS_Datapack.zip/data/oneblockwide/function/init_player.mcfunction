tp @s 0.5 130 0.5 90 0
effect give @s minecraft:slow_falling 15 0 true
effect give @s minecraft:resistance 15 4 true
spawnpoint @s 0 100 0

execute if block 0 64 0 minecraft:air if block 0 63 0 minecraft:air if block 0 62 0 minecraft:air run setblock 0 64 0 minecraft:grass_block

tag @s add obw_joined
tellraw @s ["",{"text":"========================================\n","color":"dark_aqua"},{"text":" 1-Block Wide Native Worldgen (1.21.10 - 26.3+)\n","color":"aqua","bold":true},{"text":" • Overworld & Nether: ","color":"gray"},{"text":"Native 1-Line at Z = 0 (Zero Chunk Lag!)","color":"green"},{"text":"\n • The End: ","color":"gray"},{"text":"100% Normal End Dimension","color":"yellow"},{"text":"\n • Help & FPS: ","color":"gray"},{"text":"/trigger obw_help","color":"gold","click_event":{"action":"run_command","command":"/trigger obw_help"}},{"text":"\n========================================" ,"color":"dark_aqua"}]
