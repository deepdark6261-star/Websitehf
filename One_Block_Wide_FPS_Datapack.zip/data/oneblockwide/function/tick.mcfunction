# ==========================================================
# Ultra-Light Tick Loop (0 block-filling commands = Maximum FPS!)
# ==========================================================

execute as @a[tag=!obw_joined] at @s run function oneblockwide:init_player

scoreboard players enable @a obw_fps_boost
scoreboard players enable @a obw_help

execute as @a[scores={obw_fps_boost=1..}] at @s run function oneblockwide:toggle_fps
execute as @a[scores={obw_help=1..}] at @s run function oneblockwide:show_help

scoreboard players add #fps_tick obw_timer 1
execute if score #fps_tick obw_timer matches 60.. run function oneblockwide:fps_cleanup
