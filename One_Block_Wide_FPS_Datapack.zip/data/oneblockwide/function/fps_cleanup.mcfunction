scoreboard players set #fps_tick obw_timer 0

execute if score #global obw_ultra_fps matches 1 in minecraft:overworld as @a at @s positioned ~-32 -64 3 run tp @e[type=!minecraft:player,type=!minecraft:item_frame,type=!minecraft:glow_item_frame,type=!minecraft:armor_stand,type=!minecraft:painting,type=!minecraft:boat,type=!minecraft:chest_boat,dx=64,dy=384,dz=64] ~ -500 ~
execute if score #global obw_ultra_fps matches 1 in minecraft:overworld as @a at @s positioned ~-32 -64 -67 run tp @e[type=!minecraft:player,type=!minecraft:item_frame,type=!minecraft:glow_item_frame,type=!minecraft:armor_stand,type=!minecraft:painting,type=!minecraft:boat,type=!minecraft:chest_boat,dx=64,dy=384,dz=64] ~ -500 ~
