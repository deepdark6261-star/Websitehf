# ==========================================================
# 1-Line Native Worldgen + FPS Boost (1.21.11 - 26.3+)
# ==========================================================

gamerule command_block_output false
gamerule send_command_feedback false
gamerule max_entity_cramming 6

scoreboard objectives add obw_timer dummy
scoreboard objectives add obw_fps_boost trigger
scoreboard objectives add obw_help trigger
scoreboard objectives add obw_ultra_fps dummy

scoreboard players set #global obw_ultra_fps 1
setworldspawn 0 100 0

tellraw @a ["",{"text":"[1-Line Worldgen + FPS] ","color":"aqua","bold":true},{"text":"Native 1-Block Wide Worldgen active (Overworld & Nether on ","color":"green"},{"text":"Z = 0","color":"yellow","bold":true},{"text":", Normal End, ZERO chunk-removal lag)!","color":"green"}]
