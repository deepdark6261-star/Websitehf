scoreboard objectives add cba_air dummy "Oxygen"
scoreboard objectives add cba_safe dummy
scoreboard objectives add cba_dmg_cd dummy
scoreboard objectives add cba_dragon_dead dummy

tellraw @a [{"text":"[Can't Breathe Air] ","color":"aqua","bold":true},{"text":"Universal Datapack (1.13 - 1.21+) Loaded! ","color":"green","bold":true},{"text":"Head pani/lava/sand me rakhein ya Water Breathing Potion piyein!","color":"white","bold":false}]
