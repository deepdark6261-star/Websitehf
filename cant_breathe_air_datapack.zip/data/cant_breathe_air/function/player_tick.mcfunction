# Initialize air score (300 ticks = 15 seconds = 10 bubbles)
execute unless score @s cba_air matches -20..300 run scoreboard players set @s cba_air 300

# Give constant Fire Resistance so Lava acts as a safe breathing liquid
effect give @s minecraft:fire_resistance 3 0 true

# Reset safe flag
scoreboard players set @s cba_safe 0

# 1. Check if Ender Dragon is defeated
execute if score #global cba_dragon_dead matches 1 run scoreboard players set @s cba_safe 4

# 2. Check if player's HEAD (`anchored eyes positioned ^ ^ ^`) is in Water, Bubble Column, or Lava
execute anchored eyes positioned ^ ^ ^ if block ~ ~ ~ minecraft:water run scoreboard players set @s cba_safe 1
execute anchored eyes positioned ^ ^ ^ if block ~ ~ ~ minecraft:bubble_column run scoreboard players set @s cba_safe 1
execute anchored eyes positioned ^ ^ ^ if block ~ ~ ~ minecraft:lava run scoreboard players set @s cba_safe 1

# 3. Check if player's HEAD (`anchored eyes positioned ^ ^ ^`) is inside Sand, Red Sand, or Gravel
execute anchored eyes positioned ^ ^ ^ if block ~ ~ ~ minecraft:sand run scoreboard players set @s cba_safe 2
execute anchored eyes positioned ^ ^ ^ if block ~ ~ ~ minecraft:red_sand run scoreboard players set @s cba_safe 2
execute anchored eyes positioned ^ ^ ^ if block ~ ~ ~ minecraft:gravel run scoreboard players set @s cba_safe 2

# 4. If player stepped out of water (head in air) and only had the temporary underwater effect (`cba_underwater_wb` tag), remove it immediately
execute if score @s cba_safe matches 0 if entity @s[tag=cba_underwater_wb] run effect clear @s minecraft:water_breathing
execute if score @s cba_safe matches 0 if entity @s[tag=cba_underwater_wb] run tag @s remove cba_underwater_wb

# 5. Check if player has a real Water Breathing Potion / Turtle Helmet / Conduit Power effect active in air (1.13 - 1.21+ NBT formats)
execute if score @s cba_safe matches 0 if entity @s[nbt={ActiveEffects:[{Id:13b}]}] run scoreboard players set @s cba_safe 3
execute if score @s cba_safe matches 0 if entity @s[nbt={ActiveEffects:[{Id:13}]}] run scoreboard players set @s cba_safe 3
execute if score @s cba_safe matches 0 if entity @s[nbt={ActiveEffects:[{Id:29b}]}] run scoreboard players set @s cba_safe 3
execute if score @s cba_safe matches 0 if entity @s[nbt={active_effects:[{id:"minecraft:water_breathing"}]}] run scoreboard players set @s cba_safe 3
execute if score @s cba_safe matches 0 if entity @s[nbt={active_effects:[{id:"minecraft:conduit_power"}]}] run scoreboard players set @s cba_safe 3

# 6. Keep Vanilla Bubbles 100% FULL when Head is in Water (`cba_safe == 1`)!
# First check if they already had a real potion before entering water; if not, tag them with `cba_underwater_wb` and give 2s water_breathing
execute if score @s cba_safe matches 1 unless entity @s[nbt={ActiveEffects:[{Id:13b}]}] unless entity @s[nbt={active_effects:[{id:"minecraft:water_breathing"}]}] run tag @s add cba_underwater_wb
execute if score @s cba_safe matches 1 if entity @s[tag=cba_underwater_wb] run effect give @s minecraft:water_breathing 2 0 true

# 7. Prevent vanilla suffocation damage when Head is inside Sand/Gravel
execute if score @s cba_safe matches 2 run effect give @s minecraft:resistance 1 4 true

# 8. Update Oxygen (cba_air) based on safe status
# If safe (head in water/lava, sand/gravel, or Water Breathing potion), refill oxygen quickly (+5 per tick up to 300)
execute if score @s cba_safe matches 1..4 if score @s cba_air matches ..295 run scoreboard players add @s cba_air 5
execute if score @s cba_safe matches 1..4 if score @s cba_air matches 296..300 run scoreboard players set @s cba_air 300

# If NOT safe (head is in open air without Water Breathing potion), drain oxygen (-1 per tick)
execute if score @s cba_safe matches 0 if score @s cba_air matches 1..300 run scoreboard players remove @s cba_air 1

# Play bubble pop sound every 30 ticks (1.5s) as air bubbles burst
execute if score @s cba_safe matches 0 if score @s cba_air matches 270 run playsound minecraft:block.bubble_column.bubble_pop master @s ~ ~ ~ 0.8 1.0
execute if score @s cba_safe matches 0 if score @s cba_air matches 240 run playsound minecraft:block.bubble_column.bubble_pop master @s ~ ~ ~ 0.8 1.0
execute if score @s cba_safe matches 0 if score @s cba_air matches 210 run playsound minecraft:block.bubble_column.bubble_pop master @s ~ ~ ~ 0.8 1.0
execute if score @s cba_safe matches 0 if score @s cba_air matches 180 run playsound minecraft:block.bubble_column.bubble_pop master @s ~ ~ ~ 0.8 1.0
execute if score @s cba_safe matches 0 if score @s cba_air matches 150 run playsound minecraft:block.bubble_column.bubble_pop master @s ~ ~ ~ 0.8 1.0
execute if score @s cba_safe matches 0 if score @s cba_air matches 120 run playsound minecraft:block.bubble_column.bubble_pop master @s ~ ~ ~ 0.8 1.0
execute if score @s cba_safe matches 0 if score @s cba_air matches 90 run playsound minecraft:block.bubble_column.bubble_pop master @s ~ ~ ~ 1.0 0.9
execute if score @s cba_safe matches 0 if score @s cba_air matches 60 run playsound minecraft:block.bubble_column.bubble_pop master @s ~ ~ ~ 1.0 0.8
execute if score @s cba_safe matches 0 if score @s cba_air matches 30 run playsound minecraft:block.bubble_column.bubble_pop master @s ~ ~ ~ 1.0 0.7

# 9. Display Oxygen Bubbles on Actionbar
function cant_breathe_air:hud_display

# 10. Apply Drowning Damage in Air when Oxygen hits 0 (every 20 ticks = 1 second)
execute if score @s cba_safe matches 0 if score @s cba_air matches ..0 run function cant_breathe_air:drown_damage
