# Check if Ender Dragon was defeated
execute as @a[advancements={minecraft:end/kill_dragon=true}] run scoreboard players set #global cba_dragon_dead 1

# Run main tick for all survival/adventure players
execute as @a[gamemode=!creative,gamemode=!spectator] at @s run function cant_breathe_air:player_tick
