scoreboard players add @s cba_dmg_cd 1
execute if score @s cba_dmg_cd matches 20.. run scoreboard players set @s cba_dmg_cd 0
execute if score @s cba_dmg_cd matches 1 run effect give @s minecraft:wither 2 2 true
execute if score @s cba_dmg_cd matches 1 run playsound minecraft:entity.player.hurt_drown master @s ~ ~ ~ 1.0 1.0
