# Show status on Actionbar
execute if score @s cba_safe matches 3 run title @s actionbar [{"text":"Water Breathing Active: ","color":"aqua","bold":true},{"text":"●●●●●●●●●● (Safe in Air)","color":"green"}]
execute if score @s cba_safe matches 1 if score @s cba_air matches 300 run title @s actionbar [{"text":"Breathing Liquid: ","color":"aqua"},{"text":"●●●●●●●●●●","color":"dark_aqua"}]
execute if score @s cba_safe matches 2 if score @s cba_air matches 300 run title @s actionbar [{"text":"Breathing Sand/Gravel: ","color":"yellow"},{"text":"●●●●●●●●●●","color":"gold"}]

# When refilling or draining, show exact bubble bar
execute if score @s cba_safe matches 0..2 if score @s cba_air matches 271..299 run title @s actionbar [{"text":"Oxygen: ","color":"aqua"},{"text":"●●●●●●●●●●","color":"blue"}]
execute if score @s cba_safe matches 0..2 if score @s cba_air matches 241..270 run title @s actionbar [{"text":"Oxygen: ","color":"aqua"},{"text":"●●●●●●●●●","color":"blue"},{"text":"○","color":"gray"}]
execute if score @s cba_safe matches 0..2 if score @s cba_air matches 211..240 run title @s actionbar [{"text":"Oxygen: ","color":"aqua"},{"text":"●●●●●●●●","color":"blue"},{"text":"○○","color":"gray"}]
execute if score @s cba_safe matches 0..2 if score @s cba_air matches 181..210 run title @s actionbar [{"text":"Oxygen: ","color":"aqua"},{"text":"●●●●●●●","color":"blue"},{"text":"○○○","color":"gray"}]
execute if score @s cba_safe matches 0..2 if score @s cba_air matches 151..180 run title @s actionbar [{"text":"Oxygen: ","color":"aqua"},{"text":"●●●●●●","color":"blue"},{"text":"○○○○","color":"gray"}]
execute if score @s cba_safe matches 0..2 if score @s cba_air matches 121..150 run title @s actionbar [{"text":"Oxygen: ","color":"aqua"},{"text":"●●●●●","color":"blue"},{"text":"○○○○○","color":"gray"}]
execute if score @s cba_safe matches 0..2 if score @s cba_air matches 91..120 run title @s actionbar [{"text":"Oxygen: ","color":"yellow"},{"text":"●●●●","color":"gold"},{"text":"○○○○○○","color":"gray"}]
execute if score @s cba_safe matches 0..2 if score @s cba_air matches 61..90 run title @s actionbar [{"text":"⚠ Oxygen: ","color":"yellow"},{"text":"●●●","color":"gold"},{"text":"○○○○○○○","color":"gray"}]
execute if score @s cba_safe matches 0..2 if score @s cba_air matches 31..60 run title @s actionbar [{"text":"⚠ Oxygen Low: ","color":"red","bold":true},{"text":"●●","color":"red"},{"text":"○○○○○○○○","color":"gray"}]
execute if score @s cba_safe matches 0..2 if score @s cba_air matches 1..30 run title @s actionbar [{"text":"⚠ DANGER - NEED WATER: ","color":"red","bold":true},{"text":"●","color":"dark_red"},{"text":"○○○○○○○○○","color":"gray"}]
execute if score @s cba_safe matches 0 if score @s cba_air matches ..0 run title @s actionbar [{"text":"SUFFOCATING IN AIR! GET TO WATER OR DRINK WATER BREATHING!","color":"dark_red","bold":true}]
